public class LifeService
{
    private readonly PlayerProgress _playerProgress;

    public LifeService(PlayerProgress playerProgress)
    {
        _playerProgress = playerProgress;
    }

    public void SpendLife()
    {
        _playerProgress.LoseLife();
    }

    public void AddLife()
    {
        _playerProgress.AddLife();
    }

    public void AddLives(int amount)
    {
        _playerProgress.AddLife(amount);
    }

    public bool CanPlay()
    {
        return _playerProgress.Lives <= 0;
    }
}
