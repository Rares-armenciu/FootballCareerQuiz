using UnityEngine;

public class CoinsService
{
    private readonly PlayerProgress _playerProgress;

    public CoinsService(PlayerProgress playerProgress)
    {
        _playerProgress = playerProgress;
    }

    public void AddCoins(int amount)
    {
        _playerProgress.AddCoins(amount);
    }

    public bool SpendCoins(int amount)
    {
        return _playerProgress.SpendCoins(amount);
    }
}
