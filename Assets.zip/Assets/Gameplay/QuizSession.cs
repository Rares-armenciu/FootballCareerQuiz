public class QuizSession
{
    private readonly QuizGenerator generator;
    private readonly PlayerProgress _playerProgress;
    private readonly LifeService _lifeService;
    private readonly CoinsService _coinsService;

    public QuizQuestion CurrentQuestion { get; private set; }

    public QuizSession(PlayerDatabase database, PlayerProgress playerProgress, LifeService lifeService, CoinsService coinsService)
    {
        generator = new QuizGenerator(database);
        _playerProgress = playerProgress;
        _lifeService = lifeService;
        _coinsService = coinsService;
    }

    public QuizQuestion NextQuestion()
    {
        CurrentQuestion = generator.Generate();

        return CurrentQuestion;
    }

    public bool RevealHint()
    {
        if (!CurrentQuestion.CanRevealClub)
            return false;

        if (!_coinsService.SpendCoins(50))
        {
            return false;
        }

        CurrentQuestion.RevealRandomClub();

        return true;
    }

    public bool SubmitAnswer(FootballPlayer player)
    {
        bool correct = player == CurrentQuestion.CorrectPlayer;

        if (correct)
        {
            _coinsService.AddCoins(25);
            _playerProgress.LevelUp();
        }
        else
        {
            _lifeService.SpendLife();
        }

        return correct;
    }
}