using System.Diagnostics;
using Debug = UnityEngine.Debug;

public class QuizSession
{
    private readonly QuizGenerator _quizGenerator;
    private readonly LifeService _lifeService;
    private readonly CoinsService _coinsService;
    private readonly ProgressionService _progressionService;
    private readonly StatisticsService _statisticsService;
    private readonly AchievementService _achievementsService;

    public QuizQuestion CurrentQuestion { get; private set; }

    public QuizSession(QuizGenerator generator, LifeService lifeService, CoinsService coinsService, ProgressionService progressionService, StatisticsService statisticsService, AchievementService achievementsService)
    {
        _quizGenerator = generator;
        _lifeService = lifeService;
        _coinsService = coinsService;
        _progressionService = progressionService;
        _statisticsService = statisticsService;
        _achievementsService = achievementsService;
    }

    public QuizQuestion NextQuestion()
    {
        CurrentQuestion = _quizGenerator.Generate();

        return CurrentQuestion;
    }

    public bool RevealHint()
    {
        if (!CurrentQuestion.CanRevealClub)
            return false;

        CurrentQuestion.RevealRandomClub();
        _statisticsService.UseHint();
        _progressionService.RecordHintUsed();

        _achievementsService.CheckAchievements(AchievementType.HintsUsed);

        return true;
    }

    public bool SubmitAnswer(FootballPlayer player)
    {
        bool correct = player == CurrentQuestion.CorrectPlayer;

        if (correct)
        {
            _statisticsService.RecordCorrectAnswer();
            _progressionService.RecordCorrectAnswer();
            Debug.Log("Correct Answer recorded");
        }
        else
        {
            _lifeService.SpendLife();

            _statisticsService.RecordWrongAnswer();
            _progressionService.RecordWrongAnswer();
            Debug.Log("Wrong Answer recorded");
        }

        _achievementsService.CheckAchievements(AchievementType.QuestionsAnswered);

        return correct;
    }
}