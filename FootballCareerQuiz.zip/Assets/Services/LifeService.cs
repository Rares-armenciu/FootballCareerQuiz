
using System;
using UnityEngine;

public class LifeService
{
    private readonly PlayerProgress _playerProgress;
    private const int MinutesPerLife = 20;

    public LifeService(PlayerProgress playerProgress)
    {
        _playerProgress = playerProgress;
    }

    public bool SpendLife()
    {
        if(_playerProgress.Lives <= 0)
        {
            return false;
        }

        _playerProgress.Lives--;

        if(_playerProgress.Lives == PlayerProgress.MaxLives - 1)
        {
            _playerProgress.NextLifeTime = DateTime.Now.AddMinutes(MinutesPerLife);
        }

        Debug.Log($"Life spent. Lives remaining: {_playerProgress.Lives}");
        Debug.Log($"Next life will be available at: {_playerProgress.NextLifeTime}");
        
        return true;
    }

    public void AddLife()
    {
        if(_playerProgress.Lives < PlayerProgress.MaxLives)
        {
            _playerProgress.Lives++;
        }
    }

    public void AddLives(int amount)
    {
        _playerProgress.Lives += amount;
    }

    public bool CanPlay()
    {
        return _playerProgress.Lives <= 0;
    }

    public TimeSpan GetTimeUntilNextLife()
    {
        return _playerProgress.NextLifeTime - DateTime.Now;
    }

    public void RefreshLives()
    {
        if (_playerProgress.Lives >= PlayerProgress.MaxLives)
        {
            return;
        }

        if(DateTime.Now >= _playerProgress.NextLifeTime)
        {
            AddLife();
            Debug.Log($"Life added. Lives now: {_playerProgress.Lives}");
            if (_playerProgress.Lives < PlayerProgress.MaxLives)
            {
                _playerProgress.NextLifeTime = DateTime.Now.AddMinutes(MinutesPerLife);
                Debug.Log($"Next life will be available at: {_playerProgress.NextLifeTime}");
            }
        }
    }
}
